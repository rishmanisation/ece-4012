#!/usr/bin/env python
#import rospy
#from std_msgs.msg import String
import time
import serial
import datetime

ser = serial.Serial(
              
	port='/dev/ttyUSB0',
	baudrate = 19200,
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout=1
        )
counter=0

pressure = serial.Serial(
	port = '/dev/ttyACM0',
	baudrate = 19200,    
	parity=serial.PARITY_NONE,
	stopbits=serial.STOPBITS_ONE,
	bytesize=serial.EIGHTBITS,
	timeout=1
	)     

f = open('Readings','w')
ti = int(round(time.time()*1000))
while(1):
        pt = pressure.readline()
        x=ser.readline()
        x1 = x.split('C')
        x2 = x1[1].split('P')
        x3 = x2[1].split('R')
        x4 = x3[1].split('T')
        x5 = x4[1].split('D')
        ts = int(round(time.time()*1000))
        dt = ts - ti
        output_str = '\nCompass heading = '+x2[0]+'\nPitch = '+x3[0]+'\nRoll = '+x4[0]+'\nTemp = '+x5[0]+'\nPressure = '+pt+' '+str(dt)
	f.write(output_str)
f.close()
        

       
      

       	
