Both Version 1 and Version 2 of serial_read.py perform the same function.



The sole difference is that Version 1 will display the output on the console window, while Version 2 will log all the output to a file.



Rishabh Ananthan

Anupam Goli


ECE 4012 L7A: Spring 2016


Swimming Tango
